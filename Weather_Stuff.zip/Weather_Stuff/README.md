# Weather_Stuff

# This repository includes the data needed to make historical temperature and precipitation maps in Python from Dec 2017-Jan 2018.
